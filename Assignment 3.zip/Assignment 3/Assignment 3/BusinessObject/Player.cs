﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Simple class allowing the web application to temporarily store and manipulate player information.
//         Reflects the structure of the player table in the INFT3050 database.
//===============================

namespace Assignment_3
{
    public class Player
    {
        public int playerId { get; set; }
        public string screenName { get; set; }
        public string userName { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string parentEmail { get; set; }
        public int exercisePoints { get; set; }
        public string playerPassword { get; set; }
        public bool playerAnonymous { get; set; }
        public DateTime uploadDate { get; set; }
        public int pendingPoints { get; set; }
    }
}