﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Simple class allowing the web application to temporarily store and manipulate elemental information.
//         Reflects the structure of the elemental table in the INFT3050 database.
//===============================

namespace Assignment_3
{
    public class Elemental
    {
        public int elementalId { get; set; }
        public string name { get; set; }
        public int losses { get; set; }
        public int wins { get; set; }
        public string dateCreate { get; set; }
        public int experiencePoints { get; set; }
        public int ownerId { get; set; }
        public int level { get; set; }
        public int type { get; set; }
        public bool hallOfFame { get; set; }
        public bool disabled { get; set; }
    }
}