﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Simple class allowing the web application to temporarily store and manipulate battle information.
//         Reflects the structure of the battle table in the INFT3050 database.
//===============================

namespace Assignment_3
{
    public class Battle
    {
        public int challengerId { get; set; }
        public int defenderId { get; set; }
        public int winnerId { get; set; }
        public int loserId { get; set; }
        public bool draw { get; set; }
        public string battleDate { get; set; }
        public string battleTime { get; set; }
       
    }
}