﻿using System;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Form page where users can update their details. The player's current details are pre-filled into the textboxes (and checkbox) to make it easier for the user to see what they need to change.
//When the user clicks update the updated details are passed to the PlayerManager class and from there passed to the PlayerDB class to update the player table.
//Main elements: Form page
//===============================

namespace Assignment_3
{
    public partial class ProfileUpdate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)//Checks if first time load or is a postback so the textboxes on the form arn't re-populated with the old values from the database when the update button is clicked
            {
                UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
                if (Session["playerId"] == null)
                {
                    Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
                }
                loadPlayerInfo(); //fills the textboxes on the form with the player's details
            }
        }

        // Once the update button on the form is clicked the text from the textboxes (and checkbox info) is passed to the Player DB class through the business logic layer class PlayerManager
        // The PlayerDB class will update the current player table with the info typed into the textboxes
        // If the DB is unavailable an error message will be displayed on a label on the page.
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string updateStatus = PlayerManager.updatePlayer((int)Session["playerId"], tbxScreenName.Text, tbxUserName.Text, tbxFirstName.Text, tbxLastName.Text, tbxPassword.Text, tbxParentEmail.Text, chAnon.Checked);
                if (updateStatus == "success")
                {
                    Server.Transfer("Home.aspx", true);
                }
                else
                {
                    lblErrorStatus.Text = "Database error: Profile not updated. Please try again later.";
                }
            }
            catch (Exception)
            {
                lblErrorStatus.Text = "Error: Account not updated, please try again later.<br/>";
            }
        }

        // Clears all text boxes and the checkbox on the form
        protected void btnClear_Click(object sender, EventArgs e)
        {
            tbxScreenName.Text = "";
            tbxFirstName.Text = "";
            tbxLastName.Text = "";
            tbxUserName.Text = "";
            tbxPassword.Text = "";
            tbxConfirmPassword.Text = "";
            tbxParentEmail.Text = "";
            chAnon.Checked = false;
        }

        // Call method that retrieves the player object whose playerId in the Player table matches the current session variable playerId
        // Once the player object is retrieved the player information is added to each textbox on the form to be edited as the user wishes
        public void loadPlayerInfo()
        {
            Player player = PlayerManager.GetPlayer((int)Session["playerId"]);//searches for the user based on the session variable playerId,

            //Fills form with player info
            tbxScreenName.Text = player.screenName.ToString();
            tbxFirstName.Text = player.firstName.ToString();
            tbxLastName.Text = player.lastName.ToString();
            tbxUserName.Text = player.userName.ToString();
            tbxPassword.Text = player.playerPassword.ToString();
            tbxParentEmail.Text = player.parentEmail.ToString();
            chAnon.Checked = player.playerAnonymous;
        }
    }
}