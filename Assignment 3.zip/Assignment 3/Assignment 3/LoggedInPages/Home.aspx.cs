﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Display customised labels in top right corner of the page. Also display elemental information in the formview if the player owns any elementals. Formview information changes when 
//a new elemental is selected in the drop down list.
//Main elements: Formview, drop down list, elemental image and labels. 
//===============================

namespace Assignment_3
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
            changeLabels();
        }

        //When the page first loads change the labels in the top right corner of the page to display the user's - username, screenname, full name and exercise points
        //Call method to retrieve player object from the player table based on the session id playerId
        //Label text is set to the information in this player object
        public void changeLabels()
        {
            //searches for the user based on the session variable playerId, returns a player object containing the player's information which is then assigned to the labels on the home page
            Player play = PlayerManager.GetPlayer((int)Session["playerId"]);

            lblUserName.Text = play.userName;
            lblExercisePoints.Text = play.exercisePoints.ToString();
            lblName.Text = play.firstName + " " + play.lastName;
            lblScreenName.Text = play.screenName;
        }

        //Each time the form view is bound (bound to getElemental() method with drop down list as control) check if the player has any elementals. Display a message if they do not and set the controls on the
        //page to not visible. If the player does own any elementals then change the information in the level, step and type labels to the the elemental's actual step level and type name rather than id value. 
        //Also change the image based on the elemental's type.
        protected void fvOwnerElementals_DataBound(object sender, EventArgs e)
        {
            List<Elemental> li = (List<Elemental>)Session["listPlayableElementals"];
            if (li.Count != 0)//If that player doesnt have any current elementals display a message
            {
                Label lblLevel = (Label)this.fvOwnerElementals.FindControl("lblLevel"); //Access the level label on the form view
                Label lblStep = (Label)this.fvOwnerElementals.FindControl("lblStep"); //Access the level label on the form view
                Label lblType = (Label)this.fvOwnerElementals.FindControl("lblType"); //Access the type label on the form view

                int step = ElementalLevelDB.getStep(Convert.ToInt32(lblLevel.Text)); //look up the elementalLevelId and return the elementals step
                lblStep.Text = step.ToString();

                int level = ElementalLevelDB.getLevel(Convert.ToInt32(lblLevel.Text)); //look up the elementalLevelId and return the elementals level
                lblLevel.Text = level.ToString();

                string type = ElementalTypeDB.getTypeName(Convert.ToInt32(lblType.Text)); //look up the elementalTypeId and return the type name
                lblType.Text = type;

                switch (type)//select which image to use based on elemental type
                {
                    case "Fire":
                        imgElemental.ImageUrl = "~/Images/fireElemental.png";
                        break;
                    case "Air":
                        imgElemental.ImageUrl = "~/Images/windElemental.png";
                        break;
                    case "Earth":
                        imgElemental.ImageUrl = "~/Images/earthElemental.png";
                        break;
                    case "Water":
                        imgElemental.ImageUrl = "~/Images/waterElemental.png";
                        break;
                }
            }
            else
            {
                fvOwnerElementals.Visible = false;
                ddlElementals.Visible = false;
                imgElemental.Visible = false;
                lblInfo.Text = "You don't have any elementals, go ahead and create one on the create elemental page!!";
            }
        }
    }
}