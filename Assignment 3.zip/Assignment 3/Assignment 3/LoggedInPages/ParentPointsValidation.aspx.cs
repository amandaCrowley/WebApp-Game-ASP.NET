﻿using System;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Once the player's parent has clicked on their email link they will be redirected to this page. Once the page loads the playerId and number of points to be validated is retireved from the pages URL
//   then a method is called to add these now validated points to the player table as exercise points.       
//Main elements: Status label and redirect button.
//===============================

namespace Assignment_3
{
    public partial class parentPointsValidation : System.Web.UI.Page
    {
        //Retrieves the playerId and amount of points parent has validated using Request.QueryString, then calls method to add these points as exercise points to the player in the DB
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string playerId = Request.QueryString["id"];
                int iPoints = Convert.ToInt32(Request.QueryString["points"]);

                string statusString = PlayerManager.addExercisePoints(Convert.ToInt32(playerId), iPoints); //Add validated points to user 
                if (statusString.Substring(0, 7) == "Success") //If the string starts with Success
                {
                    lblStatus.ForeColor = System.Drawing.Color.Green;
                    lblStatus.Text = statusString + " points have been added to " + PlayerManager.GetPlayer(Convert.ToInt32(playerId)).firstName + " " + PlayerManager.GetPlayer(Convert.ToInt32(playerId)).lastName + "'s account.";
                }
                else
                {
                    lblStatus.ForeColor = System.Drawing.Color.Red;
                    lblStatus.Text = statusString;
                }
            }catch(Exception ex)
            {
                lblStatus.Text = ex.Message;
            }
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/NotLoggedInPages/Login.aspx");
        }
    }
}