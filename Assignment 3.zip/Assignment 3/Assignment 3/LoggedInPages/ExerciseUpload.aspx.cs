﻿using System;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Form page that allows the user to add spendable exercise points to their account. Once the submit button is clicked the entered points are added to the pendingPoints field in the player table.
//  An email containing a link is sent to the player's parent email address. The parent then uses that email to validate the entered points. 
//  The pending points are finally added to the player's account as exercise points on the ParentPointsValidation page.
//Main elements: Form page
//===============================

namespace Assignment_3
{
    public partial class ExerciseUpload : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
        }

        //Call method to add the entered points to the pending points field in the player table of the DB
        //Also call the method that sends an email to the parent's email address, email contains point verification link
        //A player may only add points once in a 24 hour period, an error will be returned if they have already done so
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                int iPoints = Convert.ToInt32(tbxExercisePoints.Text);
                int iPlayerId = (int)Session["playerId"];
                bool addPendingStatus = PlayerManager.addPendingPoints(iPlayerId, iPoints);

                if(addPendingStatus) //Success
                {
                    PlayerManager.emailPoints(iPoints, (int)Session["playerId"]);
                    lblErrorStatus.ForeColor = System.Drawing.Color.Green;
                    lblErrorStatus.Text = "Your parent has been emailed. To add your points to your account, get them to open their email and click the confirm link.<br/>";
                }
                else //They have already uploaded today message
                {
                    lblErrorStatus.ForeColor = System.Drawing.Color.Red;
                    lblErrorStatus.Text = "Sorry, you have already uploaded exercise points today, please try again tomorrow.";
                }
            }
            catch (Exception ex)
            {
                lblErrorStatus.ForeColor = System.Drawing.Color.Red;
                lblErrorStatus.Text = ex.Message;
            }
        }

        // Clears all text boxes on the form
        protected void btnClear_Click(object sender, EventArgs e)
        {
            tbxExercisePoints.Text = "";
        }
    }
}