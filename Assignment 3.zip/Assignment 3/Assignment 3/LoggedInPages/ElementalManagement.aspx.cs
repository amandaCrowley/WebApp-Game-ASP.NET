﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Allow the user the ability to update the name of their currently playable elemental characters or retire an elemental so they are no longer playable. Player's may have up to 4 elementals at a time.
//Main elements: Gridview
//===============================

namespace Assignment_3
{
    public partial class ElementalManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
            checkCount();//checks how many elementals a user has and changes label if player has no elementals
        }

        //When the player clicks the retire button the disableElemental() method is called update the elemental's disabled field in the elemental table 
        //The listPlayableElementals session variable is also updated
        protected void GridView2_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            Session["listPlayableElementals"] = ElementalManager.getPlayableCharacters((int)Session["playerId"]);//Refresh elemental session list - takes off deleted elemental
            checkCount();//checks how many elementals a user has and changes label if player has no elementals
            lblStatus.Text = "Elemental successfully retired!";
        }

        //Once the update button is clicked change the status label
        protected void GridView2_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            lblStatus.Text = "Elemental name successfully changed!";
        }

        //Checks how many elementals the current player has, displays a different message in the label if they have none
        private void checkCount()
        {
            List<Elemental> li = (List<Elemental>)Session["listPlayableElementals"];
            if (li.Count == 0)//If that player doesnt have any current elementals display a message
            {
                lblInfo.Text = "You don't have any elementals, go ahead and create one on the create elemental page!!";
            }
            else
                lblInfo.Text = "You may change the name of any of your current elementals or delete an elemental so you can create another on the create elemental page. You may have up to four elementals at a time.<br/><br/>";
        }

        //Call method to retrieve the elementals type name based on the elemental's typeId
        //Used to display the character's type in a label on the gridview
        public string getType(int typeId)
        {
            return ElementalTypeDB.getTypeName(typeId);
        }

        //Call method to retrieve the elemental's level based on the elemental's elementalLevelId
        //Used to display the character's current level in a label on the gridview
        public int getLevel(int levelId)
        {
            return ElementalLevelDB.getLevel(levelId);
        }

        //Call method to retrieve the elemental's step based on the elemental's elementalLevelId
        //Used to display the character's current step in a label on the gridview
        public int getStep(int levelId)
        {
            return ElementalLevelDB.getStep(levelId);
        }
    }
}