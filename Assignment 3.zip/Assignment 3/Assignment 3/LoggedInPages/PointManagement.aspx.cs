﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Allow the user the ability to allocate some or all of their current exercise points to one of their currently playable elemental characters.
//Main elements: Gridview
//===============================


namespace Assignment_3
{
    public partial class PointManagement : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
            checkCount();
        }

        // Checks how many elementals the current player has, displays a different message in the label if they have none vs 1 or more.
        private void checkCount()
        {
            Player currentPlayer = PlayerManager.GetPlayer((int)(Session["playerId"]));
            List<Elemental> li = (List<Elemental>)Session["listPlayableElementals"];

            if (li.Count == 0)//If that player doesnt have any current elementals display a message
            {
                lblMessage.Text = "You don't have any elementals, go ahead and create one on the create elemental page!!";
            }
            else if(currentPlayer.exercisePoints == 0)
            {
                lblMessage.Text = "You currently have " + currentPlayer.exercisePoints + " excercise points. You'll need to upload some points before you can allocate them.<br/><br/>";
                this.gvPointManagement.Visible = false;
            }
            else
            {
                lblMessage.Text = "You may allocate your excercise points to one or more of your elementals. You currently have " + currentPlayer.exercisePoints + " excercise points. <br/><br/>";
                this.gvPointManagement.Visible = true;
            }
        }

        /// Sets range validator for the textbox - txtAddPoints, so the player can't try to add more points than they currently have.
        /// Sets the visible property of the edit button depending on the number of exercise points
        protected void gvPointManagement_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            Player currentPlayer = PlayerManager.GetPlayer((int)(Session["playerId"]));

            if ((e.Row.RowState & DataControlRowState.Edit) > 0) //checks row state(since the range validator and textbox are located in the edit item template) also > 0 included so if selection affects both normal rows and alternating rows 
            {
                //adjusts the range validator max value and error message depending on the amount of exercise points the player has
                RangeValidator rv = (RangeValidator)e.Row.FindControl("rangeValExercisePoints");
                rv.MaximumValue = currentPlayer.exercisePoints.ToString();
                rv.ErrorMessage = "Please enter a number between 1 and " + currentPlayer.exercisePoints.ToString();

                //Sets the txtAddPoints text attribute to empty when the gridview is in edit mode (rather than display the number of experience points the elemental currently has).
                //Otherwise it looks to the user that their elemental's points are being overwritten by the value they are typing in and losing the value they already have
                TextBox txtAdd = (TextBox)e.Row.FindControl("txtAddPoints");
                txtAdd.Text = "";
            }
            checkCount();
        }

        //Call method to retrieve the elemental's level based on the elemental's elementalLevelId
        //Used to display the character's current level in a label on the gridview
        public int getLevel(int levelId)
        {
            return ElementalLevelDB.getLevel(levelId);
        }

        //Call method to retrieve the elemental's step based on the elemental's elementalLevelId
        //Used to display the character's current step in a label on the gridview
        public int getStep(int levelId)
        {
            return ElementalLevelDB.getStep(levelId);
        }

        //Once the update button is clicked call method to check if the elemental leveled up
        //Change the status label depending on if the elemental leveled up or not
        //Call checkCount method to change label text if the player no longer has any elementals (if one retired to HOF)
        protected void gvPointManagement_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            int elementalId = Convert.ToInt32(e.Keys["elementalId"]); //Get elemental id from the update GridView event
            
            if (ElementalManager.levelUp(elementalId))
            {
                lblStatus.Text = "Points successfully added - " + ElementalManager.getElemental(elementalId).name + " has leveled up!!";

                List<Elemental> sessionList = (List<Elemental>)Session["listPlayableElementals"];
                List<Elemental> currentElementals = ElementalManager.getPlayableCharacters((int)(Session["playerId"]));
                if (sessionList.Count != currentElementals.Count)
                {
                    Session["listPlayableElementals"] = currentElementals; //Update session list, will be different if an elemental has been retired to the hall of fame
                    lblStatus.Text = "Wowee - " + ElementalManager.getElemental(elementalId).name + " has reach the hall of fame!!";

                    checkCount();
                }
            }
            else
            {
                lblStatus.Text = "Points successfully added!";
            }
        }
    }
}