﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Display all elemental characters in the gridview with a select button. Once a character is selected all battle information on that character is displayed in the listview.
//Main elements: Gridview - elemental info, formview - battle data
//===============================

namespace Assignment_3
{
    public partial class BattleHistory : System.Web.UI.Page
    {
        bool eleListEmpty = false; //True if gridview datasource retrieving elemental list is empty
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
        }

        #region Gridview object data source selected
        //Checks if the object data source is empty when select method is called (uses getAllElementals() method), if it is empty then do not display the elemental gridview - gvElementals
        protected void gvHistoryDataSource_Selected(object sender, ObjectDataSourceStatusEventArgs e)
        {
            if (((List<Elemental>)e.ReturnValue).Count == 0 || (List<Elemental>)e.ReturnValue == null)
            {
                lblMessage.Text = "There are no elementals to display.";
                gvElementals.Visible = false;
                eleListEmpty = true;
            }
            else
            {
                lblMessage.Text = "Select an elemental to view it's battle history:";
                gvElementals.Visible = true;
                eleListEmpty = false;
            }
        }
        #endregion

        #region Gridview selectedIndexChange, gridview pager and listView pager
        //When the gridview's select button is pushed, call the fillList method to bind the listview
        //Also set the listView pager index back to zero (otherwise when you select a new elemental the index may be on the 3rd page but the new elemental may not have a 3rd page)
        protected void gvElementals_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataPager pgr = lvBattle.FindControl("DataPager1") as DataPager;
            if (pgr != null)
            {
                  pgr.SetPageProperties(0, pgr.MaximumRows, false); //When selecting a new elemental set the pager index back to 0
            }
            
            fillList();//Then call method to rebind listview
        }

        //When the pager is used on the lvBattle listview, call fillList method to rebind listview so it pages properly - increments the StartRowIndex by MaximumRows so the new page starts at the correct place
        protected void lvBattle_PagePropertiesChanging(object sender, PagePropertiesChangingEventArgs e)
        {
            DataPager pager = (DataPager)((ListView)sender).FindControl("DataPager1");
            pager.SetPageProperties(e.StartRowIndex, e.MaximumRows, false);
            fillList(); //Then call method to rebind listview
        }

        //Clear the selected row on the gridview when the gridview pager is used
        protected void gvElementals_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvElementals.SelectedIndex = -1;
        }
        #endregion

        #region Listview itemDataBound
        //For each item (battle) bound to the listview change the values in labels lblOpponentOwner, lblOpponentName, lblBattleWon and lblDraw
        // -- Set the opponentOwner and opponentName labels to display an appropriate name, depending on the currently selected elemental's id (The battle object stores 2 elemental id's, defenderId 
        //    and challengerId, the opponent of the selected elemental will be whichever id that is not the selected elemental's id)
        // -- Add text to Battle Won label depending on whether the selected elemental was the winner of the battle
        // -- Change draw label text depending on if the battle was declared a draw
        protected void lvBattle_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                int selectedEleId = Convert.ToInt32(gvElementals.SelectedDataKey.Value);
                ListViewDataItem dataItem = (ListViewDataItem)e.Item; //Gets the object that the list item is bound to e.g. battle
                Battle batt = (Battle)dataItem.DataItem; //assign bound battle item to a new instance of battle

                //Add text to opponentname and opponentOwner labels
                Label opponentOwnerLabel = (Label)e.Item.FindControl("lblOpponentOwner");
                Label opponentLabel = (Label)e.Item.FindControl("lblOpponentName");
                if (batt.challengerId == selectedEleId) 
                {
                    Elemental opponent = ElementalManager.getElemental(batt.defenderId);
                    opponentLabel.Text = opponent.name;
                    opponentOwnerLabel.Text = PlayerManager.getElementalOwnerName(opponent.ownerId);
                }
                else
                {
                    Elemental opponent = ElementalManager.getElemental(batt.challengerId);
                    opponentLabel.Text = opponent.name;
                    opponentOwnerLabel.Text = PlayerManager.getElementalOwnerName(opponent.ownerId);
                }

                //Add text to Battle Won label
                Label wonBattleLabel = (Label)e.Item.FindControl("lblBattleWon");
                if (batt.winnerId == selectedEleId)
                {
                    wonBattleLabel.Text = "Yes";
                }else
                {
                    wonBattleLabel.Text = "No";
                }

                //Change draw label text
                Label drawLabel = (Label)e.Item.FindControl("lblDraw");
                if (batt.draw)
                {
                    drawLabel.Text = "Yes";
                    wonBattleLabel.Text = "-"; //change lblBattle won to a "-" if there was a draw as nobody won
                }
                else
                {
                    drawLabel.Text = "No";
                }
            }
        }
        #endregion

        #region FillList method(Bind listview) + getOwnerName method
        //Call method to retrieve battle information based on the elemental id (SelectedDataKey of gridview) of the selected elemental in the gridview, Which is saved to a list, the list is 
        //then bound to the Listview and appropriate messages are displayed
        private void fillList()
        {
            if (!eleListEmpty)
            {
                int eleId = Convert.ToInt32(gvElementals.SelectedDataKey.Value);
                List<Battle> batt = BattleManager.getBattle(eleId);

                lvBattle.DataSource = batt;
                lvBattle.DataBind();

                if (batt.Count == 0)
                {
                    lblBattle.Text = ""; //The list view's empty data template will display the text - This elemental has not participated in any battles.
                }
                else
                {
                    lblBattle.Text = ElementalManager.getElemental(Convert.ToInt32(gvElementals.SelectedDataKey.Value)).name + " has partcipated in the following battles: "; //Get the elemental's name using the selected index value ele id and display msg
                }
            }
        }

        //Call method to retrieve the owner's name based on the playerId
        //Used to display owner's name in a label on the gridview
        public string getOwnerName(int playerId)
        {
            return PlayerManager.getElementalOwnerName(playerId);
        }
        #endregion
    }
}