﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Almost identical to the Battle page - Displays the player's elemental and their opponent elemental. Stats for each are displayed in the DetailsView's and each elemental also has an image displayed.
//   Displays winner message in a label.
//Main elements: DetailsView x2 and Image x2. 
//===============================


namespace Assignment_3
{
    public partial class BattleOutcome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
            loadElementalInfo();
        }

        //When the page is loaded display elemental name above each image and call the method to change the image to the appropriate type 
        //Also updates the lblOutcome with the winnerMessage - informs the player who won the fight.
        //Set the backButtonPressed session variable so the player is re-directed to the home page if they press the back button
        //Call method to check if elemental session list needs to be updated
        private void loadElementalInfo()
        {
            //Change label text above images
            Elemental eleChallenger = ElementalManager.getElemental(Convert.ToInt32(Session["challengerId"]));
            lblOwnerElemental.Text = eleChallenger.name;
            Elemental eleDefender = ElementalManager.getElemental(Convert.ToInt32(Session["defenderId"]));
            lblOpponentElemental.Text = eleDefender.name;

            //Change images to appropriate type
            string challengerType = ElementalTypeDB.getTypeName(eleChallenger.type);
            loadImages(challengerType, imgLeft);//change left side image
            string defenderType = ElementalTypeDB.getTypeName(eleDefender.type);
            loadImages(defenderType, imgRight);//change right side image

            //Update winner label
            lblOutcome.Text = Session["winnerMessage"].ToString();
            Session["backButtonPressed"] = true; //If the user presses the back button the previous page(battle.aspx) checks this session variable and redirects the user to home.aspx

            refreshSessionList();//Check if the elemental session list - listPlayableElementals- needs to be refreshed
        }

        //Check if the session needs to be updated
        //If the sessionList count is different from the list retrieved by calling getPlayableCharacters() method then a character has been retired to the hall of fame and 
        //the session list needs to be updated
        //Also change the outcome label to inform the player that the winner has reached the hall of fame
        private void refreshSessionList()
        {
            List<Elemental> sessionList = (List<Elemental>)Session["listPlayableElementals"];
            List<Elemental> currentElementals = ElementalManager.getPlayableCharacters((int)(Session["playerId"]));
            if (sessionList.Count != currentElementals.Count)
            {
                Session["listPlayableElementals"] = currentElementals; //Update session list, will be different if an elemental has been retired to the hall of fame
                lblOutcome.Text = Session["winnerMessage"].ToString() + " Wowee, they have also reached the hall of fame!!";
            }
        }

        //Change the elemental's image based on the elemental's type.
        private void loadImages(string type, Image imgElemental)
        {
            switch (type)
            {
                case "Fire":
                    imgElemental.ImageUrl = "~/Images/fireElemental.png";
                    break;
                case "Air":
                    imgElemental.ImageUrl = "~/Images/windElemental.png";
                    break;
                case "Earth":
                    imgElemental.ImageUrl = "~/Images/earthElemental.png";
                    break;
                case "Water":
                    imgElemental.ImageUrl = "~/Images/waterElemental.png";
                    break;
            }
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/LoggedInPages/Home.aspx");
        }

        //Call method to retrieve the elementals type name based on the elemental's typeId
        //Used to display the character's type in a label on the detailsView
        public string getType(int typeId)
        {
            return ElementalTypeDB.getTypeName(typeId);
        }

        //Call method to retrieve the elemental's level based on the elemental's elementalLevelId
        //Used to display the character's current level in a label on the detailsView
        public int getLevel(int levelId)
        {
            return ElementalLevelDB.getLevel(levelId);
        }

        //Call method to retrieve the elemental's step based on the elemental's elementalLevelId
        //Used to display the character's current step in a label on the detailsView
        public int getStep(int levelId)
        {
            return ElementalLevelDB.getStep(levelId);
        }

        //Call method to retrieve the name of the elemental's owner based on the elemental's ownerId
        //Used to display the character's owner name rather than ownerId in a label on the detailsView
        public string getOwnerName(int playerId)
        {
            return PlayerManager.getElementalOwnerName(playerId);
        }
    }
}