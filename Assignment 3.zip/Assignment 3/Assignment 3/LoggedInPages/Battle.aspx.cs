﻿using System;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Display the player's elemental and their opponent elemental. Stats for each are displayed in the DetailsView's and each elemental also has an image displayed.
//Main elements: DetailsView x2 and Image x2. 
//===============================

namespace Assignment_3
{
    public partial class Battle1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if ((bool)Session["backButtonPressed"]) //Checks boolean to see if the back button has been pressed from the next page (fightOutcome.aspx)
            {
                Response.Redirect("~/LoggedInPages/Home.aspx");
            }else if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
            else{
                loadElementalInfo();
            }
        }

        //Call method to calculate the winner of the fight and re-direct the player to the next page - BattleOutcome
        //Set the session variable winnerMessage
        protected void btnFight_Click(object sender, EventArgs e)
        {
            Session["winnerMessage"] = BattleManager.calculateFight(Convert.ToInt32(Session["challengerId"]), (Convert.ToInt32(Session["defenderId"])));
            Response.Redirect("~/LoggedInPages/BattleOutcome.aspx");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/LoggedInPages/Home.aspx");
        }

        //When the page is loaded display elemental name above each image and call the method to change the image to the appropriate type 
        private void loadElementalInfo()
        {
            //Change label text above images
            Elemental eleChallenger = ElementalManager.getElemental(Convert.ToInt32(Session["challengerId"]));
            lblOwnerElemental.Text = eleChallenger.name; 
            Elemental eleDefender = ElementalManager.getElemental(Convert.ToInt32(Session["defenderId"]));
            lblOpponentElemental.Text = eleDefender.name;

            //Change images to appropriate type
            string challengerType = ElementalTypeDB.getTypeName(eleChallenger.type);
            loadImages(challengerType, imgLeft);//change left side image
            string defenderType = ElementalTypeDB.getTypeName(eleDefender.type);
            loadImages(defenderType, imgRight);//change right side image
        }

        //Change the elemental's image based on the elemental's type.
        private void loadImages(string type, Image imgElemental)
        {
            switch (type)
            {
                case "Fire":
                    imgElemental.ImageUrl = "~/Images/fireElemental.png";
                    break;
                case "Air":
                    imgElemental.ImageUrl = "~/Images/windElemental.png";
                    break;
                case "Earth":
                    imgElemental.ImageUrl = "~/Images/earthElemental.png";
                    break;
                case "Water":
                    imgElemental.ImageUrl = "~/Images/waterElemental.png";
                    break;
            }
        }

        //Call method to retrieve the elementals type name based on the elemental's typeId
        //Used to display the character's type in a label on the detailsView
        public string getType(int typeId)
        {
            return ElementalTypeDB.getTypeName(typeId);
        }

        //Call method to retrieve the elemental's level based on the elemental's elementalLevelId
        //Used to display the character's current level in a label on the detailsView
        public int getLevel(int levelId)
        {
            return ElementalLevelDB.getLevel(levelId);
        }

        //Call method to retrieve the elemental's step based on the elemental's elementalLevelId
        //Used to display the character's current step in a label on the detailsView
        public int getStep(int levelId)
        {
            return ElementalLevelDB.getStep(levelId);
        }

        //Call method to retrieve the name of the elemental's owner based on the elemental's ownerId
        //Used to display the character's owner name rather than ownerId in a label on the detailsView
        public string getOwnerName(int playerId)
        {
            return PlayerManager.getElementalOwnerName(playerId);
        }
    }
}