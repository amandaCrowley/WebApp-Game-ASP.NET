﻿using System;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Allow player to create a new elemental character which is stored in the elemental table of the INFT3050_BetterDB Database. Cannot have more than 4 elementals at one time.
//Main elements: Form page
//===============================

namespace Assignment_3
{
    public partial class CreateElemental : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
        }

        //Call method to add the elemental to the elemental table once the create button is clicked
        //If the elemental is successfully added to the database call the method getPlayableCharacters to update the session list
        protected void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                string createStatus = ElementalManager.addElemental(tbxElementalName.Text, ddlElementalType.SelectedValue, (int)Session["playerId"]); //Add elemental, return a string
                if(createStatus == "success")
                {
                    Session["listPlayableElementals"] = ElementalManager.getPlayableCharacters((int)Session["playerId"]);//Re-add all playable elementals to session list
                    Server.Transfer("Home.aspx", true); 
                }
                else
                {
                    lblErrorStatus.Text = createStatus; //Too many elementals msg
                }
            }
            catch (Exception)
            {
                lblErrorStatus.Text = "Elemental not created. Please try again later.<br/><br/>";
            }
        }

        // Clears all text boxes on the form
        protected void btnClear_Click(object sender, EventArgs e)
        {
            tbxElementalName.Text = "";
            ddlElementalType.Text = "--Please select a type--";
        }
    }
}