﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: The player chooses one of their characters from the drop-down list, then in the gridview they select an opponent for their character to battle.
    //All elementals displayed in the gridview are within the appropriate level range for the selected elemental to battle (within 2 steps).
//Main elements: Gridview and drop down list. 
//===============================

namespace Assignment_3
{
    public partial class Challenge : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
            checkCount();
        }

        //Check if the gridview is empty when a new elemental is selected from the drop down list(control parameter) on the page. The gridview object data source calls getCombatElementals() method
        //so if the gridview is empty then no elementals within the appropriate level range could be found for the selected elemental to battle
        //Change label/button text if gridview empty
        protected void gvChallenge_DataBound(object sender, EventArgs e)
        {
            if (gvChallenge.Rows.Count == 0) //If the gridview is empty
            {
                lblGridviewMsg.Text = "Sorry we could not find an elemental to battle within your elemental's level range. <br/> Please choose another elemental or create a new one.";
                btnContinue.Text = "Thanks, Take me to the home page!";
            }
            else
            {
                lblGridviewMsg.Text = "Select an opponent for your elemental to battle. Then click continue.";
                btnContinue.Text = "Continue";
            }
        }

        //If the gridview is empty, the player will be re-directed to the home page (button text will reflect this)
        //Initialise the session variable backButtonPressed - used to ensure the player cannot press the back button once the fight has been calculated - i.e. fightOutcome page
        //Set session variables challengerId and defenderId to be used on the next page for the battle calculations + redirect to Battle.aspx if an elemental has been selected
        protected void btnContinue_Click(object sender, EventArgs e)
        {
            Session["backButtonPressed"] = false; //Used on battle page and battle outcome pages to check that user does not press the back button

            if (gvChallenge.Rows.Count == 0) //If the gridview is empty, clicking button will redirect to home - button text was changed in databound method
            {
                Response.Redirect("~/LoggedInPages/Home.aspx");
            }
            else
            {
                if (gvChallenge.SelectedRow != null)
                {
                    Session["challengerId"] = ddlElementals.SelectedValue; //current player's selected elemental
                    Session["defenderId"] = (gvChallenge.SelectedRow.FindControl("lbleleId") as Label).Text; //selected opponent elemental = defender

                    Response.Redirect("~/LoggedInPages/Battle.aspx");
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please an elemental from the table.')", true); //Display a pop-up message if the user has not selected an elemental from the gridview
                }
            }
        }

        //Check the number of elementals the current player has
        //Change lblDropDownMessage text and set page controls to invisible if the player currently has none
        private void checkCount()
        {
            List<Elemental> li = (List<Elemental>)Session["listPlayableElementals"];
            if (li.Count == 0)//If that player doesnt have any current elementals display a message
            {
                lblDropDownMessage.Text = "You don't have any elementals, go ahead and create one on the create elemental page!!";
                this.gvChallenge.Visible = false;
                this.ddlElementals.Visible = false;
                btnContinue.Visible = false;
                
            }
            else
            {
                lblDropDownMessage.Text = "Please choose one of your elemental characters: ";
                lblGridviewMsg.Text = "Select an opponent for your elemental to battle. Then click continue.";
                this.gvChallenge.Visible = true;
                this.ddlElementals.Visible = true;
                btnContinue.Visible = true;
            }
        }

        //Call method to retrieve the elementals type name based on the elemental's typeId
        //Used to display the character's type in a label on the gridview
        public string getType(int typeId)
        {
            return ElementalTypeDB.getTypeName(typeId);
        }

        //Call method to retrieve the elemental's level based on the elemental's elementalLevelId
        //Used to display the character's current level in a label on the gridview
        public int getLevel(int levelId)
        {
            return ElementalLevelDB.getLevel(levelId);
        }

        //Call method to retrieve the elemental's step based on the elemental's elementalLevelId
        //Used to display the character's current step in a label on the gridview
        public int getStep(int levelId)
        {
            return ElementalLevelDB.getStep(levelId);
        }

        //Call method to retrieve the name of the elemental's owner based on the elemental's ownerId
        //Used to display the character's owner name rather than ownerId in a label on the gridview
        public string getOwnerName(int playerId)
        {
            return PlayerManager.getElementalOwnerName(playerId);
        }
    }
}