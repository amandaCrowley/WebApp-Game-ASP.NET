﻿using System;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Display all elemental characters who have their hall of fame boolean set to true.
//Main elements: Listview
//===============================

namespace Assignment_3
{
    public partial class LoggedInHallOfFame : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["playerId"] == null)
            {
                Response.Redirect("~/NotLoggedInPages/Login.aspx"); //If user is not logged in, redirect to login page
            }
        }

        //For each item bound to the listview from the object data source (i.e. each elemental) the type label on the listview is changed to the type name rather than type id so it's easier for the player to understand
        //Same for the owner label - owner name is displayed instead of the ownerId
        //Note: ItemDataBoundOccurs when a data item is bound to data in a ListView control - ListViewItemEventArgs enables you to access the properties of the item that is being bound 
        protected void lvHallOfFame_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                ListViewDataItem dataItem = (ListViewDataItem)e.Item; //Gets the object that the list item is bound to e.g. elemental
                Elemental ele = (Elemental)dataItem.DataItem; //assign bound elemental item to a new instance of elemental, used to search the elemental DB and display the players name rather than the player's id

                Label typeLabel = (Label)e.Item.FindControl("typeLabel"); //Find the type label and assign the type name rather than the id number to be displayed
                typeLabel.Text = ElementalTypeDB.getTypeName(ele.type);

                Label ownerLabel = (Label)e.Item.FindControl("ownerIdLabel"); //Find the owner id label and assign the player name to the label
                ownerLabel.Text = PlayerManager.getElementalOwnerName(ele.ownerId);
            }
        }
    }
}