﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Business logic layer between data access classes and user interface. Provides methods to manipulate and retrieve Battle objects
//===============================

namespace Assignment_3
{
    [DataObjectAttribute()]
    public class BattleManager
    {
        #region GetBattleList
        //Calls method to retrieve a list of all Battles the elemental with the elementalId (paramter passed in) has participated in
        //Used as on battleHistory page as data source for the Listview
        //Returns List<Battle>
        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public static List<Battle> getBattle(int elementalId)
        {
            List<Battle> battleList = BattleDB.getBattle(elementalId);
            return battleList;
        }
        #endregion

        #region Calulate fight methods
        //Starting method for fight calculation, call methods to add up bonuses
        //Then call the method to find the winner
        //Returns a string
        public static string calculateFight(int challengerId, int defenderId)
        {
            Elemental challenger = ElementalDB.getElemental(challengerId);
            Elemental defender = ElementalDB.getElemental(defenderId);

            double challengerBonus = 0.25; //challenger recieves a 25% bonus for just being the challenger
            double defenderBonus = 0;
            
            //Add type bonus to elementals if warrented
            challengerBonus = challengerBonus + addTypeBonus(challenger, defender);
            defenderBonus = defenderBonus + addTypeBonus(defender, challenger);
            
            //add random bonus to challengerBonus or defenderBonus depending on who won the roll
            addRandomBonus(ref challengerBonus, ref defenderBonus);

            //Calculates exp * bonuses and returns a string with the winner's name (or fight was a draw if it was)
            return checkWinner(challenger, challengerBonus, defender, defenderBonus);
        }

        //Calculate experiencePoints * fight bonuses for both elementals passed into the method and round them, then check which elemental won the fight
        //Call the method recordWinner() to adjust the nessecary fields in the database
        //Returns a string
        private static string checkWinner(Elemental challenger, double challengerBonus, Elemental defender, double defenderBonus)
        {
            double challengerExp = challenger.experiencePoints;
            double defenderExp = defender.experiencePoints;

            //Calculate exp after bonuses
            challengerExp = challengerExp + (challengerExp * challengerBonus);
            defenderExp = defenderExp + (defenderExp * defenderBonus);

            //round exp points
            challengerExp = Math.Round(challengerExp);
            defenderExp = Math.Round(defenderExp);

            //Check for a draw
            if (challengerExp == defenderExp)
            {
                BattleDB.addBattle(challenger.elementalId, defender.elementalId, 0, 0, true);
                return "Fight was a draw!!";
                //No exp points added for a draw
            }
            else
            {
                //Check for winner
                if (challengerExp > defenderExp)
                {
                    recordWinner(challenger, defender);
                    return challenger.name + " has won, congratulations!!";
                }
                else
                {
                    recordWinner(defender, challenger);
                    return defender.name + " has won, better luck next time...";
                }
            }
        }

        //Once the winner has been decided call methods to add experience points to the winner, adjust both elemental's BattleWon/BattleLost fields in the DB(elemental table) 
        //and add the battle to the battle table
        public static void recordWinner(Elemental winner, Elemental loser)
        {
            const double winnerBonus = 0.25; //The winner of the fight recieves a 25% bonus
            double expPoints = winner.experiencePoints + (winner.experiencePoints * winnerBonus);
            Math.Round(expPoints);

            ElementalManager.addWinLoss(winner, loser); //add each elemental's battle won or battle lost attributes
            ElementalManager.addElementalPoints(winner, expPoints); 
            BattleDB.addBattle(winner.elementalId, loser.elementalId, winner.elementalId, loser.elementalId, false); //add battle
        }
        #endregion

        #region Calculate fight bonuses methods
        //Calculate which elemental recieves the random bonus based on the random roll
        //The random bonus is added to either the challenger or the defender and both values are passed back out as ref variables
        public static void addRandomBonus(ref double challengerBonus, ref double defenderBonus)
        {
            Random rand = new Random();
            int randomNum = rand.Next(0, 2); //randomly generates either 0 or 1 ----- upper bound is exclusive

            //Check for random bonus roll
            const double randomBonus = 0.25; //A binary random generator will grant a 25% bonus to either the challenger or defender
            if (randomNum == 0)//challenger won bonus roll
            {
                challengerBonus = challengerBonus + randomBonus;
            }
            else//defender won bonus roll
            {
                defenderBonus = defenderBonus + randomBonus;
            }
        }

        //Calculate whether the elemental - ele - recieves a type bonus based on the opponent passed into the method
        //Return a double - returns 0 if no bonus
        public static double addTypeBonus(Elemental ele, Elemental opponent)
        {
            const double typeBonus = 0.15; //Elemental recieves a bonus when battling an opponent their class is strong against

            if (ele.type == 1 && opponent.type == 3) //Earth bonus over water
            {
                return typeBonus; //elemental recieves bonus
            }
            else if (ele.type == 2 && opponent.type == 1) //Air bonus over earth
            {
                return typeBonus; //elemental recieves bonus
            }
            else if (ele.type == 3 && opponent.type == 4) //Water bonus over fire
            {
                return typeBonus; //elemental recieves bonus
            }
            else if (ele.type == 4 && opponent.type == 2) //Fire bonus over air
            {
                return typeBonus; //elemental recieves bonus
            }
            else
                return 0; //no bonus
        }
        #endregion
    }
}