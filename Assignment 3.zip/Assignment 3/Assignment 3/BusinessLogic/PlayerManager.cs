﻿using System;
using System.ComponentModel;
using System.Net.Mail;
using System.Web;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Business logic layer between data access classes and user interface. Provides methods to manipulate and retrieve Player objects
//===============================

namespace Assignment_3
{
    public class PlayerManager
    {
        #region Get player methods
        //Retrieve a player object from the player table based on the playerID passed into the method
        //Returns a player object
        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public static Player GetPlayer(int playerId)
        {
            return PlayerDB.getPlayer(playerId);
        }

        //Retrieve a player object from the player table based on the player's username passed into the method
        //Used on register and login pages
        //Returns a player object
        public static Player GetPlayer(string sUserName)
        {
            return PlayerDB.getPlayer(sUserName);
        }
        #endregion

        #region Login method
        //Look up username and password values in player table and return a string if they are found.
        //Used on login page 
        //Returns a string
        public static string loginPlayer(string sName, string sPassword)
        {
            if (PlayerDB.loginPlayer(sName, sPassword))
                return "sucess";
            else
                return "";
        }
        #endregion

        #region Add and update player methods
        //Adjust a player's details in the player table from what is currently stored to the values passsed into the method
        //Used on profile update page
        //Returns a string
        public static string updatePlayer(int playerId, string sScreenN, string sUserN, string sFirstN, string sLastN, string sPassword, string sParentMail, bool bAnon)
        {
            if (PlayerDB.updatePlayerInfo(playerId, sScreenN, sUserN, sFirstN, sLastN, sPassword, sParentMail, bAnon))
                return "success";
            else
                return "";
        }

        //Add a new player's details to the player table in the DB
        //Used on register page
        //Returns a string
        public static string addPlayer(string sScreenN, string sFirstN, string sLastN, string sUserN, string sPassword, string sParentMail, bool bAnon)
        {
            Player currentPlayer = PlayerManager.GetPlayer(sUserN); //Retrieve player based on username typed in textbox, if the username is already in the player table, will come back null
            if (currentPlayer.userName == null) //if it is not already in the table continue with the insert, otherwise display an error
            {
                if (PlayerDB.addPlayer(sScreenN, sFirstN, sLastN, sUserN, sPassword, sParentMail, bAnon))
                    return "success";
                else
                    return "Database error - Account not created. Please try again later.<br/>";
            }
            else//otherwise that username is already in the table and the player needs to choose a new one
            {
                return "Error: You already have an account linked to this username.<br/>";
            }
        }
        #endregion

        #region Exercise points methods
        // Add a player's exercise points (entered into the upload exercise page) into the player table's pendingPoints field. 
        // To be validated by the parent via an email link and added to the exercisePoints field later (on ParentPointValidation page).
        // Check points not already added within the last 24 hours, if 24hrs has elasped add the points
        // When adding the pending points to the table the uploadDate field is updated for this player (instead of in addExercisePoints method), otherwise they could send multiple point validation 
        //      emails at the same time effectively getting around the 500 points a day limit
        // Used on exercise upload page
        // returns boolean
        [DataObjectMethod(DataObjectMethodType.Update)]
        public static bool addPendingPoints(int iPlayerId, int iPoints)
        {
            Player user = PlayerDB.getPlayer(iPlayerId);

            DateTime lastUploaded = user.uploadDate;
            DateTime now = DateTime.Now;

            if (lastUploaded > now.AddHours(-24) && lastUploaded <= now) //Check if last uploaded time is within 24 hour period from now
            {
                return false;
            }
            else
            {
                PlayerDB.addPendingPoints(iPlayerId, user.pendingPoints + iPoints, DateTime.Now); //add pending points to pending points already stored in the DB
                return true;
            }
        }

        //Adds the points currently in the pendingPoints field to the exercisePoints field in the player table.
        //The parent has clicked on the validation link in their email.
        //Call removePendingPoints method to remove the validated points from the pending points field in DB
        //Used on ParentPointsValidation page
        //Returns a string
        public static string addExercisePoints(int iPlayerId, int iPoints)
        {
            Player currentPlayer = PlayerDB.getPlayer(iPlayerId);
            bool bAddStatus; //successfully added to DB
            string sRemoveStatus; //Contains status on removal of pending points from the player table
            int iPointsToAdd;
            
            sRemoveStatus = PlayerManager.removePendingPoints(currentPlayer, iPoints);
            if (sRemoveStatus == "remove success") //Points removed from pending points can now be added to player's exercise points
            {
                iPointsToAdd = currentPlayer.exercisePoints + iPoints; //Add validated pending points to user's current amount of exercise points

                bAddStatus = PlayerDB.addExercisePoints(iPlayerId, iPointsToAdd);
                if (bAddStatus)
                {
                    return "Success, " + iPoints.ToString();
                }
                else
                {
                    return "Failed to add points to database, please try again later.";
                }
            }
            else if(sRemoveStatus == "less than zero")
            {
                iPointsToAdd = currentPlayer.exercisePoints + currentPlayer.pendingPoints; //Only add the amount of points the player has left in the pending points field
                bAddStatus = PlayerDB.addExercisePoints(iPlayerId, iPointsToAdd);
                return "Success, " + currentPlayer.pendingPoints.ToString();
            }
            else
            {
                return sRemoveStatus;
            }
        }

        //Call method to remove validated amount of points from the pendingPoints field in DB if the player currently has pendingPoints > 0
        //Once the user's pending points field reaches zero, thet cannot add any more points until they upload more.
        //If the amount of points they are trying to validate is greater than the amount in the pending field then set the amount in the pending field to zero (user probably trying to validate same email twice)
        //Returns a string
        public static string removePendingPoints(Player currentPlayer, int iPoints)
        {
            if (currentPlayer.pendingPoints == 0)
            {
                return "Sorry, you have already validated these points.";
            }
            else if (currentPlayer.pendingPoints - iPoints < 0)
            {
                PlayerDB.removePendingPoints(currentPlayer.playerId, 0); //Set the value in DB for pending points = 0
                return "less than zero";
            }
            else
            {
                PlayerDB.removePendingPoints(currentPlayer.playerId, currentPlayer.pendingPoints - iPoints); //Set the value in DB for pending points = current points - validated points
                return "remove success";
            }
        }

        //Call method to remove exercise points from the player table field, exercisePoints
        //Used in the elementalManager class when a player allocates their points to an elemental (on the PointManagement page)
        public static void removeExercisePoints(int iPlayerId, int iPoints)
        {
            Player currentPlayer = PlayerDB.getPlayer(iPlayerId);
            iPoints = currentPlayer.exercisePoints - iPoints;

            PlayerDB.removeExercisePoints(iPlayerId, iPoints);
        }
        #endregion

        #region email methods
        //Sends an email to the current user's parent
        //Parent needs to click the link to confirm their child has earned the specified amount of exercise points
        //They will be directed to the ParentValidation page when they click the link
        //Tested using smtp4dev, with port 25 - application needs to be open for email to successfully send
        //Used on the exerciseUpload page
        public static void emailPoints(int iPoints, int iPlayerId)
        {
            Player currentPlayer = PlayerManager.GetPlayer(iPlayerId);
            
            string strToAddress = currentPlayer.parentEmail; //Sends the email to the user's nominated parental email address
            string host = HttpContext.Current.Request.Url.Authority;

            MailMessage message = new MailMessage();
            message.IsBodyHtml = true;
            message.To.Add(strToAddress);
            message.From = new MailAddress("admin@BETTER.com", "Administrator");
            message.Subject = "Confirm exercise upload for B.E.T.T.E.R";
            message.Body = "Hello, please confirm that your child has earned " + iPoints + " exercise points in the past 24 hours by clicking this " + 
                "link: <a href=http://" + host + "/LoggedInPages/ParentPointsValidation.aspx?id=" + iPlayerId.ToString() + "&points="+ iPoints + "> Click here to validate points</a><br/>";

            SmtpClient client = new SmtpClient();
            client.Port = 25;
            client.Host = "localhost";
            client.Send(message);
        }

        //Sends an email to the address passed into the method
        //Used on the forgot password page to send the player's password to them   
        //Tested using smtp4dev, with port 25 - application needs to be open for email to successfully send
        //Returns a string
        public static string emailPassword(string sToAddress)
        {
            try
            {
                Player user = PlayerDB.getPlayer(sToAddress); //Retrieve player object based on userName entered in the textbox
                if (user.playerId != 0)
                { 
                    MailMessage message = new MailMessage();
                    message.To.Add(sToAddress);
                    message.From = new MailAddress("admin@BETTER.com", "Administration");
                    message.Subject = "Password recovery system for the B.E.T.T.E.R web application";
                    message.Body = "Hello, your password is: " + user.playerPassword;

                    SmtpClient client = new SmtpClient();
                    client.Port = 25;
                    client.Host = "localhost";
                    client.Send(message);

                    return "success";
                }else
                {
                    return "Sorry, player not found. Have you entered your email address correctly?";
                }
            }
            catch(SmtpException)
            {
                return "Email not sent, please try again later";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion

        #region Get Owners name from id
        // Call method which looks up player id in db and returns the matching player object. 
        // Depending on anon attribute returns a suitable name to display
        // returns string - name
        public static string getElementalOwnerName(int playerId)
        {
            Player player = PlayerDB.getPlayer(playerId); //Searches for player with playerId in DB

            if (player.playerAnonymous) //if the player wishes to remain anonymous return their screen name for display
                return player.screenName;
            else
                return player.firstName + " " + player.lastName; //Otherwise display their real name
        }
        #endregion
    }
}