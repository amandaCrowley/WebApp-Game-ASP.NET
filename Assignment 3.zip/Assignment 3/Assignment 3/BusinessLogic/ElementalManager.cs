﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Business logic layer between data access classes and user interface. Provides methods to manipulate and retrieve Elemental objects
//===============================

namespace Assignment_3
{
    [DataObjectAttribute()]
    public class ElementalManager
    {
        #region Elemental get/select methods
        //Calls method to retrieve a list of all elemental characters from the elemental table
        //Used as on battleHistory page
        //Returns List<Elemental>
        [DataObjectMethod(DataObjectMethodType.Select)]
        public static List<Elemental> getAllElementals()
        {
            List<Elemental> eleList = ElementalDB.getAllElementals();
            return eleList;
        }

        //Call a method to retrieve a list of all elemental characters NOT retired to the Hall of fame 
        // Used on homepage for object data source - formview
        // Used on create elemental page
        // When the drop down item is selected the select value is the elemental name which is passwd into this method
        // The name is passed to the elemental table in the database and returns all the information on that elemental to be populated in the formview
        //Returns List<Elemental>
        [DataObjectMethod(DataObjectMethodType.Select)]
        public static List<Elemental> getPlayableCharacters(int iPlayerId)
        {
            List<Elemental> eleList = ElementalDB.getPlayableCharacters(iPlayerId);
            List<Elemental> playableCharacters = new List<Elemental>(); //Used to store just the characters that the character can play
            if (eleList == null)
            {
                return playableCharacters;
            }
            else
            {
                foreach (Elemental elemental in eleList)
                {
                    if (!elemental.hallOfFame && !elemental.disabled) //boolean attributes of elemental
                        playableCharacters.Add(elemental);//add the elemental if the elemental is not retired to the hall of fame and not retired
                }
                return playableCharacters;
            }
        }

        //Call method to retrive a list of all elementals from the elemental table
        //Return a List<Elemental> of all elementals that have their HallOfFame attribute set to true
        //Used on LoggedInHallOfFame and NotLoggedInHallOfFame pages
        //Returns List<Elemental>
        [DataObjectMethod(DataObjectMethodType.Select)]
        public static List<Elemental> getHallOfFameElementals()
        {
            List<Elemental> eleList = ElementalDB.getAllElementals();
            List<Elemental> hallOfFameList = new List<Elemental>();

            foreach (Elemental elemental in eleList)
            {
                if (elemental.hallOfFame)
                    hallOfFameList.Add(elemental);
            }
            return hallOfFameList;
        }

        //Call method to retrieve elemental object from the Elemental table in the database based on the elementalId passed into the method
        //Returns Elemental object
        [DataObjectMethod(DataObjectMethodType.Select)]
        public static Elemental getElemental(int eleId)
        {
            Elemental elemental = ElementalDB.getElemental(eleId);
            return elemental;
        }

        //Call method to retrieve a list of all elementals not owned by the player with the passed in playerId
        //Returns a List<Elemental> of all NOT owned elementals that have their HallOfFame attribute set to false, disabled set to false
        //and are within 2 steps of the selected character (based on elementalId passed in)
        //Used on challenge page
        //Returns List<Elemental>
        [DataObjectMethod(DataObjectMethodType.Select)]
        public static List<Elemental> getCombatElementals(int playerId, int elementalId)
        {
            Elemental selectedCharacter = ElementalDB.getElemental(elementalId);//Retrieves the elemental that has been selected on the drop down list

            List<Elemental> notOwnedElementals = ElementalDB.notOwnedElementals(playerId); //Gets the elementals that the player does NOT own
            List<Elemental> combatList = new List<Elemental>(); 

            foreach (Elemental elemental in notOwnedElementals) //Check the not owned elemental list and save the elementals that are within 2 steps of the selected character to the combat list
            {
                if (!elemental.hallOfFame && !elemental.disabled)// add the elemental if the elemental is not retired to the hall of fame and not disabled
                    if (elemental.level <= (selectedCharacter.level +2) && elemental.level >= (selectedCharacter.level - 2)) //characters can only fight elementals within 2 steps of each other (i.e. 2 levelid difference)
                    combatList.Add(elemental);
            }
            return combatList;
        }
        #endregion

        #region Add elemental
        //Add an elemental to the database with the value of the name and type parameters passed into the method. The elemental's ownerId will be the playerId passed into the method.
        //Call method to get the type number rather than the name
        //Check player does not already have 4 elementals
        //Returns a string on success or failure of adding
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
        public static string addElemental(string eleName, string type, int playerId)
        {
            List<Elemental> eleList = getPlayableCharacters(playerId);
            int eleTypeId = ElementalTypeDB.getTypeNumber(type);

            if (eleList.Count >= 4)
            {
                return "Sorry, you may only have up to 4 elementals at a time. You'll need to delete one, by using the manage elemental page, before adding another.<br/><br/>";
            }
            else
            {
                if (ElementalDB.addElemental(eleName, eleTypeId, playerId))
                    return "success";
                else
                    return "";
            }
        }
        #endregion

        #region Update and disable methods
        //Call method to disable an elemental based on the elemental id number 
        //Used on the Elemental management page
        //Once an elemental is disabled they are no longer available for play
        //Returns success boolean
        [DataObjectMethod(DataObjectMethodType.Delete)]
        public static bool disableElemental(int elementalId)
        {
            return ElementalDB.updateDisabledStatus(elementalId);
        }

        // Call method to Update an elemental's name based on the elemental id number 
        // Used on the elemental management page to change the elemental's name
        // returns success boolean
        [DataObjectMethod(DataObjectMethodType.Update, true)]
        public static bool updateName(string name, int elementalId)
        {
            return ElementalDB.updateElementalName(name, elementalId);
        }
        #endregion

        #region Add points, levelUp & addWin/loss methods
        // Add a player's exercise points to an elemental's experience points.
        //Used on PointManagement page
        //Call method to add points to the elemental
        //Call method to Remove the added points from the player
        //If elemental exercise points exceed 11501 call method to adjust level, add 11501 points and change hall of fame boolean
        //Point management page will call levelUp() method to check if elemental has leveled up when row is updated
        [DataObjectMethod(DataObjectMethodType.Update)]
        public static void addElementalPoints(int experiencePoints, int iPlayerId, int elementalId)
        {
            Elemental ele = ElementalDB.getElemental(elementalId);
            int iElementalPoints = experiencePoints + ele.experiencePoints; //add passed in to points to what is already in DB
            
            if(iElementalPoints >= 11501)//check if need to add elemental to the hall of fame
            {
                ElementalDB.addPoints(elementalId, 11501); //updates the elemental's points to 11501 as points do not get allocated past 11501
                ElementalDB.updateHallOfFame(elementalId, true); //Hall of fame boolean changed in DB to true
                ElementalDB.updateLevel(ele.elementalId, 16);//Sets the elemental's level id to 16

                if (iElementalPoints > 11501)
                {
                    experiencePoints = 11501 - ele.experiencePoints; //Only the amount needed to reach 11501 is removed from the player
                }
            }
            else
            {
                ElementalDB.addPoints(elementalId, iElementalPoints);
            }
            PlayerManager.removeExercisePoints(iPlayerId, experiencePoints); //remove exercise points from current player
        }

        //Call method to add points to the expPoints field in elemental table to the elemental who won (on battle page)
        //If elemental exercise points exceed 11501 call method to adjust level, add 11501 points and change hall of fame boolean
        //Call method to check if elemental has leveled up
        //Used in BattleManager class after fight has been caclulated
        public static void addElementalPoints(Elemental ele, double exPoints)
        {
            if (exPoints >= 11501)//check if need to add elemental to the hall of fame
            {
                ElementalDB.addPoints(ele.elementalId, 11501); //updates the elemental's points to 11501 as points do not get allocated past 11501
                ElementalDB.updateHallOfFame(ele.elementalId, true); //Hall of fame boolean changed in DB to true
                ElementalDB.updateLevel(ele.elementalId, 16);//Sets the elemental's level id to 16
            }
            else if (ElementalDB.addPoints(ele.elementalId, Convert.ToInt32(exPoints)))//if add successful
            {
                levelUp(ele.elementalId); //check if need to level up
            }
        }

        //Update the battleWon and battleLost fields of the winner and loser (respectively) in the elemental table
        //Used in BattleManager class after fight has been caclulated
        public static void addWinLoss(Elemental winner, Elemental loser)
        {
            ElementalDB.updateWin(winner.elementalId, winner.wins + 1);
            ElementalDB.updateLoss(loser.elementalId, loser.losses + 1);
        }

        //This method is used once points have been added to an elemental's expPoints field 
        //Call method - calculateLevel - to calculate what current level bracket the elemental is in (looks up ElementalLevel table in database), if the level returned is different from the current 
        //level then the elemental has leveled up
        //Update the elemental's elementalLevelId in the elemental table if it has leveled up
        //Used in this class in addElementalPoints() method
        //Return bool
        public static bool levelUp(int elementalId)
        {
            int levelId = 0;
            Elemental ele = ElementalDB.getElemental(elementalId);

            levelId = ElementalLevelDB.calculateLevelBracket(ele.experiencePoints); //Returns which level bracket the experience points sit in i.e. exp points 1401 - 1900 = levelid 6
            if (ele.level != levelId)//If the level returned is different from the current level then elemental has leveled up
            {
                ElementalDB.updateLevel(ele.elementalId, levelId);
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion
    }
}