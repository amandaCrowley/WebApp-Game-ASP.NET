﻿using System;
using System.Configuration;
using System.Data.SqlClient;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Stores simple lookup methods to retrieve values from the ElementalLevel table in the INFT3050_BetterDB
// Note: elementalLevelId is different from level - elementalLevelId is unique e.g. elementalLevelId 6 = level 2, step 2 and experience points range 1401-1900
//  where level 2 could refer to level 2, steps 1-4
//===============================

namespace Assignment_3
{
    public class ElementalLevelDB
    {
        //Retrieves the step from the ElementalLevel table based on the elementalLevelId parameter
        public static int getStep(int elementalLevelId)
        {
            int step = 0;
            SqlConnection connection = new SqlConnection(GetConnectionString());
               
            SqlCommand cmd = new SqlCommand("SELECT characterStep FROM elementalLevel WHERE elementalLevelId=@levelId", connection);
            cmd.Parameters.AddWithValue("@levelId", elementalLevelId);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) //true if there is a matching levelID found
                        step = Convert.ToInt32(reader["characterStep"]);
                }
            }
            return step;
        }

        //Retrieves the level from the ElementalLevel table based on the elementalLevelId parameter
        public static int getLevel(int elementalLevelId)
        {
            int level = 0;
            SqlConnection connection = new SqlConnection(GetConnectionString());
            
            SqlCommand cmd = new SqlCommand("SELECT characterLevel FROM elementalLevel WHERE elementalLevelId=@levelId", connection);
            cmd.Parameters.AddWithValue("@levelId", elementalLevelId);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) //true if there is a matching levelID found
                        level = Convert.ToInt32(reader["characterLevel"]);
                }
            }
            return level;
        }

        //Retrieves the elementalLevelId from the ElementalLevel table based on the expPoints parameter passed into the method - 
        //The method figures out which level bracket that experience point value is in and returns the elementalLevelId for that bracket
        public static int calculateLevelBracket(int expPoints)
        {
            int levelId = 0;
            SqlConnection connection = new SqlConnection(GetConnectionString());
                 
            SqlCommand cmd = new SqlCommand("SELECT elementalLevelId FROM elementalLevel WHERE expPointLower <= @expPoints AND expPointUpper >= @expPoints", connection);
            cmd.Parameters.AddWithValue("@expPoints", expPoints);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) 
                        levelId = Convert.ToInt32(reader["elementalLevelId"]);
                }
            }
            return levelId;
        }

        //Return Database connection string
        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings
                ["betterWebAppConnectionString"].ConnectionString;
        }

    }
}