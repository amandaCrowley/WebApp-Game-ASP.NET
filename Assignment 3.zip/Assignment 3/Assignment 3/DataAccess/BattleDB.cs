﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Store methods which select, insert and update info from the battle table in the INFT3050_BetterDB
// This information is passed to and from the business logic layer classes - mainly the BattleManager class
//===============================

namespace Assignment_3
{
    public class BattleDB
    {
        #region getBattle
        //Retrieve battle information from the battle table in the database, only retrieve battles that the elemental with parameter - elementalId - has participated in
        //store this information in a list of type Battle
        //If the winnerId and loserId for a battle is null, set them to 0 in the battle list
        //Returns an Battle list
        public static List<Battle> getBattle(int elementalId)
        {
            List<Battle> battleList = new List<Battle>();
            SqlConnection connection = new SqlConnection(GetConnectionString());

            SqlCommand cmd = new SqlCommand("SELECT * FROM battle WHERE challengerId = @elementalId OR defenderId = @elementalId; ", connection);
            cmd.Parameters.AddWithValue("@elementalId", elementalId);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    Battle battle;
                    while (reader.Read())
                    {

                        battle = new Battle();
                        battle.challengerId = Convert.ToInt32(reader["challengerId"]);
                        battle.defenderId = Convert.ToInt32(reader["defenderId"]);
                        if (reader["winnerId"] != DBNull.Value) //Checks that the  winnerId value stored in DB is not null, if it is null winnerId will be 0 in battleList
                            battle.winnerId = Convert.ToInt32(reader["winnerId"]);
                        if(reader["loserId"] != DBNull.Value)//Checks that the  loserId value stored in DB is not null, if it is null loserId will be 0 in battleList
                            battle.loserId = Convert.ToInt32(reader["loserId"]);
                        battle.draw = (bool)reader["draw"];
                        battle.battleDate = reader["battleDate"].ToString();
                        battle.battleTime = reader["battleTime"].ToString();
                        battleList.Add(battle);
                    }
                }
            }
            return battleList;
        }
        #endregion

        #region addBattle
        //Add a new battle record to the battle table with the details passed into the method.
        //Used in recordWinner() method in BattleManager class
        //The battleDate and battleTime fields in the battle table are set to the current date and time formatted as strings
        //If the battle is a draw the winnerId and loserId fields are set to null
        //Returns true if successful
        public static bool addBattle(int challengerId, int defenderId, int winnerId, int loserId, bool draw)
        {
            try
            {
                DateTime currDate = System.DateTime.Now;
                string currentDate = currDate.ToString("dd/MM/yyyy"); 
                string displayTime = currDate.ToString("HH:mm"); // String will display as "17:10" 24hr format

                SqlConnection connection = new SqlConnection(GetConnectionString());

                SqlCommand cmd = new SqlCommand("INSERT INTO battle(challengerId, defenderId, winnerId, loserId, draw, battleDate, battleTime) "
                    + "VALUES(@challengerId, @defenderId, @winnerId, @loserId, @draw, @currentDate, @currentTime)", connection);
                cmd.Parameters.AddWithValue("@challengerId", challengerId);
                cmd.Parameters.AddWithValue("@defenderId", defenderId);
                if (draw)
                {
                    cmd.Parameters.AddWithValue("@winnerId", DBNull.Value);
                    cmd.Parameters.AddWithValue("@loserId", DBNull.Value); 
                }
                else
                {
                    cmd.Parameters.AddWithValue("@winnerId", winnerId);
                    cmd.Parameters.AddWithValue("@loserId", loserId);
                }
                cmd.Parameters.AddWithValue("@draw", draw);
                cmd.Parameters.AddWithValue("@currentDate", currentDate);
                cmd.Parameters.AddWithValue("@currentTime", displayTime);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region DB helper methods
        //Return Database connection string
        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings
                ["betterWebAppConnectionString"].ConnectionString;
        }

        //Passes in the SQL cmd opens the connection to the DB executes the query, then closes the connection
        private static void excecuteSQLCommand(SqlCommand cmd, SqlConnection connection)
        {
            try
            {
                cmd.CommandType = CommandType.Text;

                connection.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
    #endregion
    }
}