﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Store methods which select, insert and update info from the elemental table in the INFT3050_BetterDB
// This information is passed to and from the business logic layer classes - mainly the ElementalManager class
//===============================

namespace Assignment_3
{
    public class ElementalDB
    {
        #region addElemental
        //Stores a new elemental character in the elemental table
        //The fields name, type and ownerId are passed in as the method's parameters - sName, eleTypeId and playerId respectively
        //The dateCreated field is set as the current date formatted as a string
        //Used on the create elemental page
        //The elementalId in the table auto-increments as more characters are added (set as identity, primary key)
        public static bool addElemental(string sName, int eleTypeId, int playerId)
        {
            try
            {
                string currentDate = System.DateTime.Today.ToString("dd/MM/yyyy");
                SqlConnection connection = new SqlConnection(GetConnectionString());

                SqlCommand cmd = new SqlCommand("INSERT INTO elemental(Name, dateCreated, ownerId, elementalTypeId) "
                    + "VALUES(@sName, @currentDate, @ownerId, @eleTypeId)", connection);
                cmd.Parameters.AddWithValue("@sName", sName);
                cmd.Parameters.AddWithValue("@currentDate", currentDate);
                cmd.Parameters.AddWithValue("@ownerId", playerId);
                cmd.Parameters.AddWithValue("@eleTypeId", eleTypeId);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region get elemental methods
        //Retrieve all Elemental character information from the elemental table in the database and store this information in a list of type elemental
        //Does not store character in the list if that elemental's disabled field = true
        //Returns an elemental list
        public static List<Elemental> getAllElementals()
        {
            List<Elemental> eleList = new List<Elemental>();
            SqlConnection connection = new SqlConnection(GetConnectionString());

            SqlCommand cmd = new SqlCommand("SELECT * FROM elemental", connection);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    Elemental ele;
                    while (reader.Read())
                    {
                        ele = new Elemental();
                        ele.elementalId = Convert.ToInt32(reader["elementalId"]);
                        ele.name = reader["Name"].ToString();
                        ele.losses = Convert.ToInt32(reader["battleLost"]);
                        ele.wins = Convert.ToInt32(reader["battleWon"]);
                        ele.dateCreate = reader["dateCreated"].ToString();
                        ele.experiencePoints = Convert.ToInt32(reader["expPoints"]);
                        ele.ownerId = Convert.ToInt32(reader["ownerId"]);
                        ele.level = Convert.ToInt32(reader["elementalLevelId"]);
                        ele.type = Convert.ToInt32(reader["elementalTypeId"]);
                        ele.hallOfFame = (bool)(reader["hallOfFame"]);
                        ele.disabled = (bool)(reader["disabled"]);
                        if (!ele.disabled) //add if not disabled
                            eleList.Add(ele);
                    }
                }
            }
            return eleList;
        }

        //Retrieve a elemental's details from the elemental table based on the eleId passed into the method.
        //Store these details in the new elemental object ele
        //Returns Elemental object - elementalId's are unique so this method will only return one Elemental object
        public static Elemental getElemental(int eleId)
        {
            Elemental ele = new Elemental();
            SqlConnection connection = new SqlConnection(GetConnectionString());

            SqlCommand cmd = new SqlCommand("SELECT * FROM elemental WHERE elementalId = @elementalId", connection);
            cmd.Parameters.AddWithValue("@elementalId", eleId);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ele.elementalId = Convert.ToInt32(reader["elementalId"]);
                        ele.name = reader["Name"].ToString();
                        ele.losses = Convert.ToInt32(reader["battleLost"]);
                        ele.wins = Convert.ToInt32(reader["battleWon"]);
                        ele.dateCreate = reader["dateCreated"].ToString();
                        ele.experiencePoints = Convert.ToInt32(reader["expPoints"]);
                        ele.ownerId = Convert.ToInt32(reader["ownerId"]);
                        ele.level = Convert.ToInt32(reader["elementalLevelId"]);
                        ele.type = Convert.ToInt32(reader["elementalTypeId"]);
                        ele.hallOfFame = (bool)(reader["hallOfFame"]);
                        ele.disabled = (bool)(reader["disabled"]);
                    }
                }
            }
            return ele;
        }

        //Used to retrieve all of a player's owned elementals i.e. all elementals with the ownerId = playerId passed into the method
        //Used in elemental manager class in the getPlayableCharacters method
        //Returns a List of type Elemental
        public static List<Elemental> getPlayableCharacters(int iPlayerId)
        {
            List<Elemental> eleList = new List<Elemental>();
            SqlConnection connection = new SqlConnection(GetConnectionString());
            SqlCommand cmd = new SqlCommand("SELECT * FROM elemental where ownerId = @playerId; ", connection);
            cmd.Parameters.AddWithValue("@playerId", iPlayerId);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    Elemental ele;
                    while (reader.Read()) 
                    {
                        
                        ele = new Elemental();
                        ele.elementalId = Convert.ToInt32(reader["elementalId"]);
                        ele.name = reader["Name"].ToString();
                        ele.losses = Convert.ToInt32(reader["battleLost"]);
                        ele.wins = Convert.ToInt32(reader["battleWon"]);
                        ele.dateCreate = reader["dateCreated"].ToString();
                        ele.experiencePoints = Convert.ToInt32(reader["expPoints"]);
                        ele.ownerId = Convert.ToInt32(reader["ownerId"]);
                        ele.level = Convert.ToInt32(reader["elementalLevelId"]);
                        ele.type = Convert.ToInt32(reader["elementalTypeId"]);
                        ele.hallOfFame = (bool)(reader["hallOfFame"]);
                        ele.disabled = (bool)(reader["disabled"]);
                        eleList.Add(ele);
                    }
                }
            }
            return eleList;
        }

        //Used to retrieve all of a player's NOT owned elementals i.e. all elementals with the ownerId != playerId passed into the method
        //Used in elemental manager class in the getCombatElementals() method
        //Returns a List of type Elemental
        public static List<Elemental> notOwnedElementals(int iPlayerId)
        {
            List<Elemental> eleList = new List<Elemental>();
            SqlConnection connection = new SqlConnection(GetConnectionString());     
            SqlCommand cmd = new SqlCommand("SELECT * FROM elemental where ownerId != @playerId;", connection); //get non-owned elementals
            cmd.Parameters.AddWithValue("@playerId", iPlayerId);


            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    Elemental ele;
                    while (reader.Read()) 
                    {
                        ele = new Elemental();
                        ele.elementalId = Convert.ToInt32(reader["elementalId"]);
                        ele.name = reader["Name"].ToString();
                        ele.losses = Convert.ToInt32(reader["battleLost"]);
                        ele.wins = Convert.ToInt32(reader["battleWon"]);
                        ele.dateCreate = reader["dateCreated"].ToString();
                        ele.experiencePoints = Convert.ToInt32(reader["expPoints"]);
                        ele.ownerId = Convert.ToInt32(reader["ownerId"]);
                        ele.level = Convert.ToInt32(reader["elementalLevelId"]);
                        ele.type = Convert.ToInt32(reader["elementalTypeId"]);
                        ele.hallOfFame = (bool)(reader["hallOfFame"]);
                        ele.disabled = (bool)(reader["disabled"]);
                        eleList.Add(ele);
                    }
                }
            }
            return eleList;
        }
        #endregion

        #region update and delete methods
        //Update an elemental's name in the elemental table with the name parameter and matching elementalId
        //Used on the elemental management page - through ElementalManager class
        //Returns true if successful
        public static bool updateElementalName(string name, int eleId)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE elemental SET Name = @name WHERE elementalId = @eleId", connection);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@eleId", eleId);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update an elemental's disabled field to false for the elemental with the matching elementalId in the elemental table
        //Used on the elemental management page - through ElementalManager class
        //Returns true if successful
        public static bool updateDisabledStatus(int eleId)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE elemental SET disabled = @disabled WHERE elementalId = @eleId", connection);
                cmd.Parameters.AddWithValue("@eleId", eleId);
                cmd.Parameters.AddWithValue("@disabled", true);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update an elemental's expPoints field to the value of the parameter - expPoints - for the elemental with the matching eleId in the elemental table
        //Used in ElementalManager class methods - addElementalPoints
        //Returns true if successful
        public static bool addPoints(int eleId, int expPoints)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE elemental SET expPoints = @expPoints WHERE elementalId = @eleId", connection);
                cmd.Parameters.AddWithValue("@eleId", eleId);
                cmd.Parameters.AddWithValue("@expPoints", expPoints);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update an elemental's elementalLevelId field to the value of the parameter - levelId - for the elemental with the matching eleId in the elemental table
        //Used in ElementalManager class methods - LevelUp, and both addElementalPoints methods
        //Returns true if successful
        public static bool updateLevel(int eleId, int levelId)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE elemental SET elementalLevelId = @levelId WHERE elementalId = @eleId", connection);
                cmd.Parameters.AddWithValue("@eleId", eleId);
                cmd.Parameters.AddWithValue("@levelId", levelId);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update an elemental's hallOfFame field to true for the elemental with the matching eleId in the elemental table
        //Used in ElementalManager class methods - addElementalPoints
        //Returns true if successful
        public static bool updateHallOfFame(int eleId, bool bHOF)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE elemental SET hallOfFame = @bHOF WHERE elementalId = @eleId", connection);
                cmd.Parameters.AddWithValue("@eleId", eleId);
                cmd.Parameters.AddWithValue("@bHOF", bHOF);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update an elemental's battleWon field to the value of the parameter - currentWins - for the elemental with the matching eleId in the elemental table
        //Used in ElementalManager class method - addWinLoss
        //Returns true if successful
        public static bool updateWin(int eleId, int currentWins)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE elemental SET battleWon = @currentWins WHERE elementalId = @eleId", connection);
                cmd.Parameters.AddWithValue("@eleId", eleId);
                cmd.Parameters.AddWithValue("@currentWins", currentWins);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update an elemental's battleLost field to the value of the parameter - currentLosses - for the elemental with the matching eleId in the elemental table
        //Used in ElementalManager class method - addWinLoss
        //Returns true if successful
        public static bool updateLoss(int eleId, int currentLosses)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE elemental SET battleLost = @currentLosses WHERE elementalId = @eleId", connection);
                cmd.Parameters.AddWithValue("@eleId", eleId);
                cmd.Parameters.AddWithValue("@currentLosses", currentLosses);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region DB helper methods
        //Return Database connection string
        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings
                ["betterWebAppConnectionString"].ConnectionString;
        }

        //Passes in the SQL cmd opens the connection to the DB executes the query, then closes the connection
        private static void excecuteSQLCommand(SqlCommand cmd, SqlConnection connection)
        {
            try
            {
                cmd.CommandType = CommandType.Text;

                connection.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        #endregion
    }
}