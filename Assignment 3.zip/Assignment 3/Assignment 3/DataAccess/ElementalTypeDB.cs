﻿using System;
using System.Configuration;
using System.Data.SqlClient;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Stores simple lookup methods to retrieve values from the ElementalType table in the INFT3050_BetterDB
//===============================

namespace Assignment_3
{
    public class ElementalTypeDB
    {
        //Retrieves the elemental type name from the ElementalType table based on the typeId parameter
        public static string getTypeName(int typeId)
        {
            string type = "";
            SqlConnection connection = new SqlConnection(GetConnectionString());
                
            SqlCommand cmd = new SqlCommand("SELECT characterType FROM elementalType WHERE elementalTypeId=@typeId", connection);
            cmd.Parameters.AddWithValue("@typeId", typeId);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader()) 
                {
                    if (reader.Read()) //true if there is a matching type name found
                        type = reader["characterType"].ToString();
                }
            }
            return type;
        }

        //Retrieves the elemental typeId from the ElementalType table based on the typeName parameter
        public static int getTypeNumber(string typeName)
        {
            int typeId = 0;
            SqlConnection connection = new SqlConnection(GetConnectionString());
  
            SqlCommand cmd = new SqlCommand("SELECT elementalTypeId FROM elementalType WHERE characterType=@type", connection);
            cmd.Parameters.AddWithValue("@type", typeName);

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) //true if there is a matching type id found
                        typeId = Convert.ToInt32(reader["elementalTypeId"]);
                }
            }


            return typeId;
        }

        //Return Database connection string
        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings
                ["betterWebAppConnectionString"].ConnectionString;
        }
    }
}