﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Store methods which select, insert and update info from the player table in the INFT3050_BetterDB
// This information is passed to and from the business logic layer classes - mainly the PlayerManager class
//===============================

namespace Assignment_3
{
    public class PlayerDB
    {
        #region addPlayer and updatePlayerInfo methods
        //Add a new player record to the player table with the details passed into the method.
        //Used on the register page - through PlayerManager class
        //Returns true if successful
        //The playerId in the player table auto-increments as more players are added (set as identity, primary key)
        public static bool addPlayer(string sScreenN, string sFirstN, string sLastN, string sUserN, string sPassword, string sParentMail, bool bAnon)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());               
                SqlCommand cmd = new SqlCommand("INSERT INTO Player(screenName, userName,firstName,lastName,parentEmail,playPassword,playerAnonymous) "
                    + "VALUES(@screenName, @userName, @firstName, @lastName, @parentEmail, @playPassword, @playerAnonymous)", connection);
                cmd.Parameters.AddWithValue("@screenName", sScreenN);
                cmd.Parameters.AddWithValue("@userName", sUserN);
                cmd.Parameters.AddWithValue("@firstName", sFirstN);
                cmd.Parameters.AddWithValue("@lastName", sLastN);
                cmd.Parameters.AddWithValue("@parentEmail", sParentMail);
                cmd.Parameters.AddWithValue("@playPassword", sPassword);
                cmd.Parameters.AddWithValue("@playerAnonymous", bAnon);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update a player's details in the player table with the details passed into the method.
        //Used on the profile update page - through PlayerManager class
        //Returns true if successful
        public static bool updatePlayerInfo(int iPlayerID, string sScreenN, string sUserN, string sFirstN, string sLastN, string sPassword, string sParentMail, bool bAnon)
        {
            try { 
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE player SET screenName = @screenName, userName = @userName, firstName = @firstName, lastName = @lastName, parentEmail=@parentEmail,playPassword=@playPassword, playerAnonymous = @playerAnonymous WHERE playerId = @playerId", connection);
                cmd.Parameters.AddWithValue("@screenName", sScreenN);
                cmd.Parameters.AddWithValue("@userName", sUserN);
                cmd.Parameters.AddWithValue("@firstName", sFirstN);
                cmd.Parameters.AddWithValue("@lastName", sLastN);
                cmd.Parameters.AddWithValue("@parentEmail", sParentMail);
                cmd.Parameters.AddWithValue("@playPassword", sPassword);
                cmd.Parameters.AddWithValue("@playerAnonymous", bAnon);
                cmd.Parameters.AddWithValue("@playerId", iPlayerID);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region Exercise point methods
        //Update the number of pendingPoints in the player table for the player with the playerId passed in
        //Set the uploadDate field to the parameter uploadDate
        //Used on exercise upload page - through PlayerManager class
        //Returns true if successful
        public static bool addPendingPoints(int iPlayerId, int iPendingPoints, DateTime uploadDate)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE player SET pendingPoints = @iPendingPoints, uploadDate = @uploadDate WHERE playerId = @iPlayerId", connection);
                cmd.Parameters.AddWithValue("@iPlayerId", iPlayerId);
                cmd.Parameters.AddWithValue("@iPendingPoints", iPendingPoints);
                cmd.Parameters.AddWithValue("@uploadDate", uploadDate);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Update the number of exercise points to paramter - iPoints - for the player with the playerId passed in (in the player table)
        //Used on ParentPointsValidation page - through PlayerManager class
        //Returns true if successful
        public static bool addExercisePoints(int iPlayerId, int iPoints)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlCommand cmd = new SqlCommand("UPDATE player SET exercisePoints = @exercisePoints WHERE PlayerId = @playerId", connection);
                cmd.Parameters.AddWithValue("@playerId", iPlayerId);
                cmd.Parameters.AddWithValue("@exercisePoints", iPoints);


                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Remove exercise points from exercisePoints field in player table for the player with the playerId passed in
        //Used in the elementalManager class when a player allocates their points to an elemental (on the PointManagement page)
        //Returns true if successful
        public static bool removeExercisePoints(int iPlayerID, int iPoints)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());

                SqlCommand cmd = new SqlCommand("UPDATE player SET exercisePoints = @exercisePoints WHERE playerId = @playerId", connection);
                cmd.Parameters.AddWithValue("@playerId", iPlayerID);
                cmd.Parameters.AddWithValue("@exercisePoints", iPoints);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Remove points from pendingPoints field in player table for the player with the playerId passed in
        //Used in PlayerManager class when removed points are added to the expPoints field
        //Returns true if successful
        public static bool removePendingPoints(int iPlayerID, int iPoints)
        {
            try
            {
                SqlConnection connection = new SqlConnection(GetConnectionString());

                SqlCommand cmd = new SqlCommand("UPDATE player SET pendingPoints = @pendingPoints WHERE playerId = @playerId", connection);
                cmd.Parameters.AddWithValue("@playerId", iPlayerID);
                cmd.Parameters.AddWithValue("@pendingPoints", iPoints);

                excecuteSQLCommand(cmd, connection);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region login method
        //Check the player table for matching userName and playPassword against the values passed into the method (sUserName and sPassword).
        //Used on the login page - through PlayerManager class
        //Return true if successful
        public static bool loginPlayer(string sUserName, string sPassword)
        {
            SqlConnection connection = new SqlConnection(GetConnectionString());
            //Searches the player table for the username and password that the user has typed into the login form      
            SqlCommand cmd = new SqlCommand("SELECT * FROM player WHERE userName=@userName AND playPassword=@pwd", connection);
            cmd.Parameters.AddWithValue("@userName", sUserName);
            cmd.Parameters.AddWithValue("@pwd", sPassword);
            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) //If player containing the matching username + pwd found then reader.Read() will be true
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
        #endregion

        #region GetPlayer methods
        //Retrieve a player's details from the player table based on the iPlayerID passed into the method.
        //Store these details in the new Player object play
        //Returns a player object - playerId's are unique so this method will only return one player object
        public static Player getPlayer(int iPlayerID)
        {
            SqlConnection connection = new SqlConnection(GetConnectionString());
            SqlCommand cmd = new SqlCommand("SELECT * FROM player WHERE playerId=@playerId", connection);
            cmd.Parameters.AddWithValue("@playerId", iPlayerID);
            Player play = new Player();

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        DateTime date;

                        play.playerId = Convert.ToInt32(reader["playerId"]);
                        play.screenName = reader["screenName"].ToString();
                        play.userName = reader["userName"].ToString();
                        play.firstName = reader["firstName"].ToString();
                        play.lastName = reader["lastName"].ToString();
                        play.parentEmail = reader["parentEmail"].ToString();
                        play.exercisePoints = Convert.ToInt32(reader["exercisePoints"]);
                        play.playerPassword = reader["playPassword"].ToString();
                        play.playerAnonymous = (bool)reader["playerAnonymous"];
                        if (DateTime.TryParse(reader["uploadDate"].ToString(), out date))//Try convert to datetime and pass out to date variable
                        {
                            play.uploadDate = date;
                        }
                        play.pendingPoints = Convert.ToInt32(reader["pendingPoints"]);
                    }
                }
            }
            return play;
        }

        //Retrieve a player's details from the player table based on the username passed into the method
        //Store these details in the new Player object play
        //Used on the login page to first set the session variable playerId
        //Used on register page to check that the username the player is trying to register is not already stored in the player table
        //Returns a player object - Usernames are unique (as they are an email) so this method will only return one player object
        public static Player getPlayer(string sUserName)
        {
            SqlConnection connection = new SqlConnection(GetConnectionString()); 
            SqlCommand cmd = new SqlCommand("SELECT * FROM player WHERE userName=@userName", connection);
            cmd.Parameters.AddWithValue("@userName", sUserName);
            Player play = new Player();

            using (connection)
            {
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        DateTime date;

                        play.playerId = Convert.ToInt32(reader["playerId"]);
                        play.screenName = reader["screenName"].ToString();
                        play.userName = reader["userName"].ToString();
                        play.firstName = reader["firstName"].ToString();
                        play.lastName = reader["lastName"].ToString();
                        play.parentEmail = reader["parentEmail"].ToString();
                        play.exercisePoints = Convert.ToInt32(reader["exercisePoints"]);
                        play.playerPassword = reader["playPassword"].ToString();
                        play.playerAnonymous = (bool)reader["playerAnonymous"];
                        if (DateTime.TryParse(reader["uploadDate"].ToString(), out date)) //Try convert to datetime and pass out to date variable
                        { 
                            play.uploadDate = date;
                        }
                        play.pendingPoints = Convert.ToInt32(reader["pendingPoints"]);
                    }
                }
            }
            return play;
        }
    
        #endregion

        #region DB helper methods
        //Return Database connection string
        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings
                ["betterWebAppConnectionString"].ConnectionString;
        }

        //Passes in the SQL cmd opens the connection to the DB executes the query, then closes the connection
        private static void excecuteSQLCommand(SqlCommand cmd, SqlConnection connection)
        {
            try
            {
                cmd.CommandType = CommandType.Text;

                connection.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        #endregion

    }
}