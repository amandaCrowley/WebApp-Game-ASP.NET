﻿using System;
using System.Collections.Generic;
using System.Configuration;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: A simple form page that asks for the user’s username and password. Once the user clicks login the player table is checked for matching values and if successful transfers the player to the home page.
//Main elements: Form page - also forgot password and register links.
//===============================

namespace Assignment_3
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }


        //Call method to match username and password user has typed in with values in player table
        //If successfull, add playerId to the session object playerId and create another session object containing any playable characters they have - listPlayableElementals
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                //Checks the database for a matching username and password - returns a string e.g. sucess or invalid...
                string sloginStatus = PlayerManager.loginPlayer(tbxUserName.Text, tbxPassword.Text);
                if (sloginStatus == "sucess")
                {
                    Player player = PlayerManager.GetPlayer(tbxUserName.Text);
                    Session["playerId"] = player.playerId; //sets the session variable playerId to the matching player's id
                    Session["listPlayableElementals"] = null;

                    List<Elemental> listElementals = ElementalManager.getPlayableCharacters(player.playerId);
                    if (listElementals != null)
                    {
                        Session["listPlayableElementals"] = listElementals; //Stores all of the player's playable elementals
                    }
                    Response.Redirect("~/LoggedInPages/Home.aspx");
                }
                else
                    lblLoginStatus.Text = "Invalid user name or password, please try again.";
            }
            catch (Exception)
            {
                lblLoginStatus.Text = "Sorry, login process failed, please try again later.";
            }
        }

        // Clears all text boxes on the form
        protected void btnClear_Click(object sender, EventArgs e)
        {
            tbxUserName.Text = "";
            tbxPassword.Text = "";
        }
    }
}