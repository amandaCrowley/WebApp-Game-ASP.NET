﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Form page where new users register their details. Player's details are passed to the PlayerManager class and from there passed to the PlayerDB class to be added to the database.
//===============================

namespace Assignment_3
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }

        //Check player is not already stored in the database. 
        //Call add player method to add player details to the player table.
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string addStatus = PlayerManager.addPlayer(tbxScreenName.Text, tbxFirstName.Text, tbxLastName.Text, tbxUserName.Text, tbxPassword.Text, tbxParentEmail.Text, chAnon.Checked);
                if (addStatus == "success")
                {
                    Response.Redirect("Login.aspx", true);
                }
                else
                {
                    lblErrorStatus.Text = addStatus; //Not created msg
                }
            }
            catch (Exception)
            {
                lblErrorStatus.Text = "Error: Account not created, please try again later.<br/>";
            }
        }

        //Clears all textboxes on the page, untick checkbox
        protected void btnClear_Click(object sender, EventArgs e)
        {
            tbxScreenName.Text = "";
            tbxFirstName.Text = "";
            tbxLastName.Text = "";
            tbxUserName.Text = "";
            tbxPassword.Text = "";
            tbxConfirmPassword.Text = "";
            tbxParentEmail.Text = "";
            chAnon.Checked = false;
        }
    }
}
