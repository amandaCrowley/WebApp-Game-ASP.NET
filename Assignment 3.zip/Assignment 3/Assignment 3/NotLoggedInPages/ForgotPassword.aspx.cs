﻿using System;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Simple form page that sends an email to the address that the user has typed into the textbox.The email contains the password associated with that username,
//    retrieved from the player table in the database.
//Main elements: Form page
//===============================

namespace Assignment_3
{
    public partial class ForgotPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }

        //Calls a method to send an email to the username(email address) provided.
        protected void btnSendEmail_Click(object sender, EventArgs e)
        {
            try
            {
                string sEmailSent = PlayerManager.emailPassword(tbxUserName.Text);
                if (sEmailSent == "success")
                {
                    lblEmailStatus.ForeColor = System.Drawing.Color.Green;
                    lblEmailStatus.Text = "Email sent!";
                }else
                {
                    lblEmailStatus.ForeColor = System.Drawing.Color.Red;
                    lblEmailStatus.Text = sEmailSent; //Username not found in the player table
                }
            }
            catch (Exception)
            {
                lblEmailStatus.ForeColor = System.Drawing.Color.Red;
                lblEmailStatus.Text = "Email not sent, please try again";
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            tbxUserName.Text = "";
        }
    }
}