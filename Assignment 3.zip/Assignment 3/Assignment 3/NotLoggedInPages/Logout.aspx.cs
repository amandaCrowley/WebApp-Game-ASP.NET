﻿using System;
//===============================
//AUTHOR: Amanda Crowley
//CREATE DATE: 22/08/16
//PURPOSE: Logout page - clears session variables
//Main elements: Large heading on page
//===============================

namespace Assignment_3
{
    public partial class Logout : System.Web.UI.Page
    {
        //Clears session variables
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.RemoveAll();
        }
    }
}